
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base Masters</title>
    <link rel="stylesheet" href="css.css">
    <link rel="shortcut icon" href="GUANTELOGO.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"></head>

    <body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="GUANTELOGO.png" width="50" height="50" alt="Logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto"> 
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">INICIO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="boletos.html  ">BOLETOS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.extrabase.tv/affiliate/sitioCa%C3%B1eros">JUEGOS EN VIVO</a>
                        </li>
                        <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="extrasDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">MÁS
</a>
<ul class="dropdown-menu" aria-labelledby="extrasDropdown">
    <li><a class="dropdown-item" href="logout.php">CERRAR SESIÓN</a></li>
</ul>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-bs-interval="1800">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="proye1.jpg" class="d-block w-200" alt="...">
          </div>
          <div class="carousel-item">
            <img src="proye2.jpg" class="d-block w-200" alt="...">
          </div>
          <div class="carousel-item">
            <img src="proye3.jpg" class="d-block w-200" alt="...">
          </div>
        </div>
    </div>
    <section id="quienes-section" class="text-center text-dark big-light features-icons quienes-section">
        <div class="container">
            <div class="row">
                <div>
                    <img src="NOTICIA.png" alt="">
                </div>
            </div>
            <div class="row mt-4">
                <div class="col">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2945"class="link-table">En peleado doubleheader Cañeros logra barrida</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2944"class="link-table">Steven Moya reforzará a la Fuerza Verde</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2943"class="link-table">La Fuerza Verde inicia con triunfo ante Mayos</a></th>
                            </tr>
                            <tr>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2942"class="link-table">Venados rompen dominio verde</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2941"class="link-table">Aseguran serie comandados por el Capitán</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2940"class="link-table">Cañonazo de Balentien en victoria sobre Venados</a></th>
                            </tr>
                            <tr>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2939"class="link-table">Cobran el tercero con intereses</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2938"class="link-table">Miranda luce pero falla la defensa</a></th>
                                <th class="text-center align-middle"><a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2937"class="link-table">Tropiezan los verdes en arranque de segunda vuelta</a></th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <div id="carouselExampleIndicators" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active"> 
            <div class="overlay-image" style="background-image:url(./cañe.jpeg); background-size: cover;"></div>  
            <div class="container2">
                <h1>VENADOS ROMPEN DOMINIO VERDE</h1>
                <p>Los Mochis, Sinaloa. 30 de noviembre de 2023 (Prensa Club Cañeros).</p>
                <a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2942" class="btn btn-lg btn-primary">VER MÁS</a>
            </div>
          </div>
          <div class="carousel-item">
            <div class="overlay-image" style="background-image:url(./pelado.jpg); background-size: cover;"></div>  
            <div class="container2">
                <h1>CAÑEROS LOGRA BARRIDA</h1>
                <p>Navojoa, Sonora. 3 de diciembre de 2023 (Prensa Club Cañeros).</p>
                <a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2945" class="btn btn-lg btn-primary">VER MÁS</a>
            </div>
          </div>
          <div class="carousel-item">
            <div class="overlay-image" style="background-image:url(./jal231205.jpg); background-size: cover;"></div>  
            <div class="container2">
                <h1>LOCALES SE QUEDAN CON EL PRIMERO</h1>
                <p>Zapopan, Jalisco. 5 de diciembre de 2023 (Prensa Club Cañeros).</p>
                <a href="https://xn--caeros-xwa.net/noticias/leer.php?paginado=2946" class="btn btn-lg btn-primary">VER MÁS</a>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
    </div>
 
    <table>
        <tr>
            <td>
                <div class="circle-container">
                    <img src="yasmany.jpeg.crdownload" alt="Yasmany">
                </div>
                <br>
                <button onclick="redirectYasmany()">Yasmany Tomas</button>
            </td>
            <td>
                <div class="circle-container">
                    <img src="Rodolfo Amador.jpeg" alt="Rodolfo">
                </div>
                <br>
                <button onclick="redirectRodolfo()">Rodolfo Amador</button>
            </td>
            <td>
                <div class="circle-container">
                    <img src="Wladimir Balentien.jpeg" alt="Wladimir">
                </div>
                <br>
                <button onclick="redirectWladimir()">Wladimir Balentien</button>
            </td>
            <td>
                <div class="circle-container">
                    <img src="Justin Dean.jpeg" alt="Justin">
                </div>
                <br>
                <button onclick="redirectJustin()">Justin Dean</button>
            </td>
            <td>
                <div class="circle-container">
                    <img src="Eric Filia.jpeg" alt="Eric">
                </div>
                <br>
                <button onclick="redirectEric()">Eric Filia</button>
            </td>
            <td>
                <div class="circle-container">
                    <img src="Isaac Rodriguez.jpeg" alt="Isaac">
                </div>
                <br>
                <button onclick="redirectIsaac()">Isaac Rodriguez</button>
            </td>
            <!-- Agrega más celdas según sea necesario -->
        </tr>
    </table>
    <script>
        function redirectYasmany() {
            window.location.href = "https://twitter.com/eltanquetomas";
        }
        function redirectRodolfo() {
            window.location.href = "https://twitter.com/verdesxsiempre";
        }
        function redirectWladimir() {
            window.location.href = "https://twitter.com/cocobalentien";
        }
        function redirectJustin() {
            window.location.href = "https://twitter.com/justindean400m";
        }
        function redirectEric() {
            window.location.href = "https://twitter.com/Liga_Arco";
        }
        function redirectIsaac() {
            window.location.href = "https://twitter.com/joframaso";
        }

    </script>
<section id="quienes-section" class="text-center text-dark big-light features-icons quienes-section">
    <div class="container">
        <div class="row">
            <div>
                <img src="REDES.png" alt="">
            </div>
        
            <div class="col-md-6">
                <h3>Síguenos en Facebook:</h3>
                
                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fverdesxsiempre&tabs&width=300&height=200&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </div>

            <div class="col-md-6">
                <h3>Síguenos en Instagram:</h3>

                <iframe src="https://www.instagram.com/verdesxsiempre/embed/" width="300" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </div>
        </div>
    </div>
</section>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
