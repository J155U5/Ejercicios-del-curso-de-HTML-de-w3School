<?php
// Verifica si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establece la conexión a la base de datos (reemplaza con tus propios detalles de conexión)
    $serverName = "localhost"; // Puede ser "localhost" o la IP del servidor SQL Server
    $connectionOptions = array(
        "Database" => "BASEMAX",
        "Uid" => "sa",
        "PWD" => "050402"
    );

    $conn = sqlsrv_connect($serverName, $connectionOptions);

    // Verifica la conexión
    if (!$conn) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Recibe y limpia los datos del formulario
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $contrasena = $_POST["contrasena"]; // Almacena la contraseña directamente

    // Inserta los datos en la base de datos
    $sql = "INSERT INTO usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)";
    $params = array($nombre, $correo, $contrasena);

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt) {
        header("Location: login.html");
    } else {
        echo "Error: " . print_r(sqlsrv_errors(), true);
    }

    // Cierra la conexión
    sqlsrv_close($conn);
}
?>
