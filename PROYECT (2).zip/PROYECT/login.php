<?php
session_start(); // Inicia la sesión

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera los datos del formulario
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    // Conexión a la base de datos (ajusta la configuración según tus necesidades)
    $serverName = "localhost";
    $connectionOptions = array(
        "Database" => "BASEMAX",
        "Uid" => "sa",
        "PWD" => "050402",
    );
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn) {
        // Consulta para verificar las credenciales en la base de datos
        $query = "SELECT id, nombre, correo FROM usuarios WHERE correo = ? AND contrasena = ?";
        $params = array($correo, $contrasena);
        $stmt = sqlsrv_query($conn, $query, $params);

        if ($stmt === false) {
            die(print_r(sqlsrv_errors(), true));
        }

        // Verifica si se encontraron resultados
        if (sqlsrv_has_rows($stmt)) {
            // Inicio de sesión exitoso
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $_SESSION['id'] = $row['id'];
            $_SESSION['nombre'] = $row['nombre'];
            header("Location: index.php"); // Redirige a la página principal
        } else {
            echo "Credenciales incorrectas";
        }

        sqlsrv_close($conn);
    } else {
        die(print_r(sqlsrv_errors(), true));
    }
}
?>
