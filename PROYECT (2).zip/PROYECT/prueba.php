<?php

class Cconexion{

    function ConexionBD(){

        $host='localhost';
        $dbname='BASEMAX';
        $username='sa';
        $pasword ='050402';
        $puerto=1433;

        try {
            $conn = new PDO ("sqlsrv:Server=$host,$puerto;Database=$dbname",$username,$pasword);
            echo "Conexión exitosa";
        } catch(PDOException $exp) {
            echo "Error de conexión: " . $exp->getMessage();
        }

        return $conn;
    }

}

?>
