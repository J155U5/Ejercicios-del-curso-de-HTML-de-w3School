<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base Masters</title>
    <link rel="stylesheet" href="css.css">
    <link rel="shortcut icon" href="GUANTELOGO.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"></head>
    <style>
        .estadio-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        .asiento-button {
            width: 50px;
            height: 50px;
            margin: 10px;
            background-color: #28a745; /* Color verde */
            color: #000; /* Texto negro */
            border: 1px solid #000;
            border-radius: 5px;
            font-weight: bold; /* Texto en negrita */
            cursor: pointer;
        }
        #lista-precios-section {
    text-align: center;
    margin-top: 20px;
}

#lista-precios-section h2 {
    margin-bottom: 20px;
}

#lista-precios-section img {
    display: block;
    margin: 0 auto;
    max-width: 100%;
    height: auto;
}

    </style>
    <body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="GUANTELOGO.png" width="50" height="50" alt="Logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto"> 
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">INICIO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="boletos.html">BOLETOS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.extrabase.tv/affiliate/sitioCa%C3%B1eros">JUEGOS EN VIVO</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="extrasDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                MÁS
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="extrasDropdown">
                                <li><a class="dropdown-item" href="login.html">CERRAR SESIÓN</a></li>

                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div id="carouselExampleIndicators" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
          
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active"> 
            <div class="overlay-image" style="background-image:url(./mochis\ hermo\ 1.jpg); background-size: cover;"></div>  
            <div class="container2">
                <h1>Los Mochis VS Hermosillo</h1>
                <p>Estadio Fernando Valenzuela 17/Oct/2023.</p>
                
            </div>
          </div>
          <div class="carousel-item">
            <div class="overlay-image" style="background-image:url(./mochis\ hermo\ 2.jpg); background-size: cover;"></div>  
            <div class="container2">
                <h1>Los Mochis VS Hermosillo</h1>
                <p>Estadio Fernando Valenzuela 17/Oct/2023.</p>
                
            </div>
          </div>
          <div class="carousel-item">
            <div class="overlay-image" style="background-image:url(./mochis\ hermo\ 3.jpg); background-size: cover;"></div>  
            <div class="container2">
                <h1>Los Mochis VS Hermosillo</h1>
                <p>Estadio Fernando Valenzuela 17/Oct/2023.</p>
            </div>
          </div>
       
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
    </div>
    <section id="estadios-section" class="text-center">
        <div class="container estadio-container">
            <!-- Contenedor de asientos -->
            <?php
                $filas = 20; // Número de filas
                $columnas = 10; // Número de columnas

                $letras = range('A', 'Z'); // Generar letras del alfabeto

                for ($fila = 1; $fila <= $filas; $fila++) {
                    for ($columna = 1; $columna <= $columnas; $columna++) {
                        $asiento = $letras[$columna - 1] . $fila;
                        echo '<button class="asiento-button" data-asiento="' . $asiento . '">' . $asiento . '</button>';
                    }
                }
            ?>
        </div>
    </section>
    <section id="lista-precios-section">
        <h2>Lista de Precios</h2>
        <img src="GRAN SORTEO.png" alt="Imagen de Precios">
    </section>
<section id="quienes-section" class="text-center text-dark big-light features-icons quienes-section">
    <div class="container">
        <div class="row">
            <div>
                <img src="REDES.png" alt="">
            </div>
        
            <div class="col-md-6">
                <h3>Síguenos en Facebook:</h3>
                
                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fverdesxsiempre&tabs&width=300&height=200&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </div>

            <div class="col-md-6">
                <h3>Síguenos en Instagram:</h3>

                <iframe src="https://www.instagram.com/verdesxsiempre/embed/" width="300" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </div>
        </div>
    </div>
</section>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
